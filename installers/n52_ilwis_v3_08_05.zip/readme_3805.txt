The following bugs were solved, some new features were added:

- Map Window selections: added the option to select polygons (previously only points and segments could be selected)
- Added ellipsoidal Plate Carree coordinate system
- Table Join operation: added the missing option to join a column of type Coord, making it possible to e.g. join the coordinates of a pointmap into its attribute table
- Space Time Cube: added the 3D wind-rose option; added XT, XY, YT lines
- Applications: added Parallax Correction of clouds for MSG images (under Image Processing), and Probability Density raster generation (frmprobabilitydensity)

- Improved the compatibility on computers with Intel HD Graphics or combo-graphics-hardware (potential crashes when opening a Map Window). Therefore the "Software Rendering" option in the ILWIS Preferences can be disabled for those who enabled it as a workaround.
- Restored the Epipolar Stereopair functionality (both creation and viewing in the stereoscope window)
- Restored the Import->ILWIS->TIFF functionality (message DATUM.DEF was not found)
- Many stability and usability improvements in the Import functionality for both maps and tables, and recognition of more projections (all Import methods, including ILWIS, GDAL and PostgreSQL)
- Stability improvements in the Export functionality (both ILWIS and GDAL)
- Calling external commands works again (message Exit Code 1)
- Restored the rectangle-based Zoom-Out functionality
- Restored the No-Zoom option for raster images that maps each raster pixel to an on-screen pixel. Use the "Global Tools->Geometry->GeoReference" tool and select the georeference that corresponds to the raster image, in order to display it unprojected.
- MapGlue now allows gluing large images
- Improved the table Window summary statistics for boolean columns and for selected records
- Improved the interactive slicing application
- Solved the problem whereby the Representation Editor would show a wrong color ramp in the preview
- Solved potential crashes and wrong results in the vector operations Union and Intersect
- Solved "vector<T> too long" error when opening corrupted polygon maps
- Improvements in per-class hatching and transparency for polygon layers
- Solve potential crashes when opening "Use As" data
- Now the Color Composite application creates 24 bits files when this option is selected (previously it was always 8 bits)
- Open Street Map: corrected the zoom level making the labels readable, and solved potential deadlocks and crashes. Known issue: OSM may not show in 3D-view, depending on the viewing angle.
- DEM Hydro-Processing functions: solved potential "vector <T> too long" and "Find Error" problems, and the menu is now arranged in the recommended workflow order.
- Maplist Statistics now work again: solved the "Encountered an improper argument" error
- Solved inconsistent behavior in iff statement when one of the parameters is undef (?): iff (a,b,?) is now the same as iff(not a,?,b)
- Solved crashes or empty results in copying a map to the clipboard when using WMS and Open Street Map, or when using Software Rendering
- Solved crashes and inconsistent behavior in the Cross Section, Hovmoeller and Track Profile tools
- Solved many random crashes in ILWIS

Bas Retsios
2015-09-02
